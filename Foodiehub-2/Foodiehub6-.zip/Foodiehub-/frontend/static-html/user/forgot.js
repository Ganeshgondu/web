document.getElementById('forgot-form').addEventListener('submit', async function (e) {
  e.preventDefault();
  const email = document.getElementById('email').value.trim();

  try {
    const res = await fetch('http://localhost:5000/api/auth/forgot-password', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email })
    });

    const data = await res.json();
    if (res.ok) {
      alert('Reset link sent to your email.');
      this.reset();
    } else {
      alert(data.message || 'Error sending reset link');
    }
  } catch (err) {
    console.error(err);
    alert('Something went wrong');
  }
});
